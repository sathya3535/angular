(function()
{
 
var  app  =  angular.module ('sathya' , [] );
 
console.log('script execute');

app.controller('sathyacontroller',function(){
	
 this.product=s;
	 
});


var s=
[
{
	
name: 'teddy',
	
price: 500,
	
description: '* * * * ',
image:'s.jpg',

},

{
	
name: 'rose',
	
price: 250,
	
description: '12345 ',
image:'s.jpg'
,},

{
	
name: 'Kite',
		
price: 100,
	
description: '* * && ',
image:'s.jpg',
 }
];
})();